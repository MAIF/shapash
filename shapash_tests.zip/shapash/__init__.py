  
"""Top-level package."""

__author__ = """Yann Golhen, Yann Lagré, Sebastien Bidault, Maxime Gendre"""
__email__ = 'yann.golhen@maif.fr, yann.lagre@maif.fr, sebabstien.bidault@maif.fr, maxime.gendre@maif.fr'
__version__ = '0.1.4'