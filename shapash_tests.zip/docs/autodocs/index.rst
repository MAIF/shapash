.. index:

Documentation
=============

.. toctree::
   :maxdepth: 2

   shapash.explainer.rst
   shapash.data.rst


License is Apache Software License 2.0