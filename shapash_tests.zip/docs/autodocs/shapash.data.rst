Data Loader
===========

To test **Shapash** library, it provides a data_loader function which returns clearly
labeled datasets.
These datasets allow any new user to easily test the shapash library
on a classification or regression problem




.. automodule:: shapash.data.data_loader
   :members:
   :undoc-members:
   :show-inheritance:
