.. explainer:

Use Shapash with Shap or Lime
=============================

.. toctree::
    :maxdepth: 2


    tuto-expl01-Shapash-Viz-using-Shap-contributions
    tuto-expl02-Shapash-Viz-using-Lime-contributions