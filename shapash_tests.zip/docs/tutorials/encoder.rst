.. encoder:

The different ways to use Encoders and Dictionaries
===================================================

.. toctree::
    :maxdepth: 2


    tuto-encoder01-using-category_encoder
    tuto-encoder02-using-columntransformer
    tuto-encoder03-using-dict