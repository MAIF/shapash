.. plot:

More details about charts and plots
===================================

.. toctree::
    :maxdepth: 2

    tuto-plot03-features-importance
    tuto-plot02-contribution_plot
    tuto-plot01-local_plot-and-to_pandas
    tuto-plot04-compare_plot